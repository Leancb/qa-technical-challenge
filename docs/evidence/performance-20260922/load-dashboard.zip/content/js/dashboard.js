/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 94.66635801675284, "KoPercent": 5.333641983247168};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.3910508672205218, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.3431767542654824, 500, 1500, "HTTP_01_Home"], "isController": false}, {"data": [0.4175177331303153, 500, 1500, "HTTP_04_Confirmar"], "isController": false}, {"data": [0.41049006242376407, 500, 1500, "HTTP_03_Selecionar"], "isController": false}, {"data": [0.4018505142228184, 500, 1500, "HTTP_02_Buscar"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 116637, 6221, 5.333641983247168, 3269.134091240375, 313, 70895, 1217.0, 14324.300000000025, 23170.600000000006, 33056.750000000044, 172.17673959960203, 1003.8153239016143, 42.78480030706306], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["HTTP_01_Home", 32763, 3472, 10.59732014772762, 4948.3397735250155, 319, 70241, 1257.0, 20733.40000000001, 26050.750000000004, 37639.47000000009, 48.38138048560062, 215.34917057932728, 5.153338462739707], "isController": false}, {"data": ["HTTP_04_Confirmar", 26927, 781, 2.900434508114532, 2477.1792995877863, 313, 70895, 890.0, 5413.9000000000015, 9742.800000000003, 30002.0, 40.26593732289163, 224.01098588236042, 16.036309644863614], "isController": false}, {"data": ["HTTP_03_Selecionar", 27874, 861, 3.088900050226017, 2549.976214393345, 318, 56667, 915.5, 5715.9000000000015, 10392.30000000001, 30003.0, 41.54606077046674, 267.83372890064436, 11.756406835019332], "isController": false}, {"data": ["HTTP_02_Buscar", 29073, 1107, 3.8076565885873492, 2799.796821793398, 320, 62697, 938.0, 6677.400000000009, 15572.000000000015, 30003.0, 43.03343294981727, 302.96866783814096, 10.187018199620777], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["Non HTTP response code: org.apache.http.conn.ConnectTimeoutException/Non HTTP response message: Connect to www.blazedemo.com:443 [www.blazedemo.com/64.233.190.121, www.blazedemo.com/2800:3f0:4003:c08:0:0:0:79] failed: Connect timed out", 151, 2.427262497990677, 0.1294614916364447], "isController": false}, {"data": ["Non HTTP response code: org.apache.http.conn.ConnectTimeoutException/Non HTTP response message: Connect to www.blazedemo.com:443 [www.blazedemo.com/172.217.192.121, www.blazedemo.com/2800:3f0:4003:c0f:0:0:0:79] failed: Read timed out", 557, 8.95354444623051, 0.47755000557284566], "isController": false}, {"data": ["Non HTTP response code: org.apache.http.conn.ConnectTimeoutException/Non HTTP response message: Connect to www.blazedemo.com:443 [www.blazedemo.com/142.251.0.121, www.blazedemo.com/2800:3f0:4003:c0f:0:0:0:79] failed: Connect timed out", 19, 0.30541713550876065, 0.016289856563526155], "isController": false}, {"data": ["Non HTTP response code: org.apache.http.conn.ConnectTimeoutException/Non HTTP response message: Connect to www.blazedemo.com:443 [www.blazedemo.com/142.251.0.121, www.blazedemo.com/2800:3f0:4003:c0f:0:0:0:79] failed: Read timed out", 7, 0.11252210255585919, 0.006001526102351741], "isController": false}, {"data": ["Non HTTP response code: org.apache.http.conn.ConnectTimeoutException/Non HTTP response message: Connect to www.blazedemo.com:443 [www.blazedemo.com/64.233.190.121, www.blazedemo.com/2800:3f0:4003:c08:0:0:0:79] failed: Read timed out", 301, 4.838450409901945, 0.25806562240112485], "isController": false}, {"data": ["Non HTTP response code: org.apache.http.conn.ConnectTimeoutException/Non HTTP response message: Connect to www.blazedemo.com:443 [www.blazedemo.com/172.217.192.121, www.blazedemo.com/2800:3f0:4003:c0f:0:0:0:79] failed: Connect timed out", 328, 5.272464234045973, 0.2812143659387673], "isController": false}, {"data": ["Non HTTP response code: org.apache.http.conn.ConnectTimeoutException/Non HTTP response message: Connect to www.blazedemo.com:443 [www.blazedemo.com/172.217.192.121] failed: Connect timed out", 377, 6.060118951936988, 0.3232250486552295], "isController": false}, {"data": ["Non HTTP response code: org.apache.http.conn.ConnectTimeoutException/Non HTTP response message: Connect to www.blazedemo.com:443 [www.blazedemo.com/172.217.192.121, www.blazedemo.com/2800:3f0:4003:c08:0:0:0:79] failed: Connect timed out", 134, 2.153994534640733, 0.11488635681644761], "isController": false}, {"data": ["Non HTTP response code: java.net.SocketException/Non HTTP response message: Connection reset", 97, 1.55923484970262, 0.08316400456115984], "isController": false}, {"data": ["Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: www.blazedemo.com:443 failed to respond", 948, 15.238707603279215, 0.8127781064327786], "isController": false}, {"data": ["Non HTTP response code: org.apache.http.conn.ConnectTimeoutException/Non HTTP response message: Connect to www.blazedemo.com:443 [www.blazedemo.com/172.217.192.121, www.blazedemo.com/2800:3f0:4003:c08:0:0:0:79] failed: Read timed out", 218, 3.504259765311043, 0.1869046700446685], "isController": false}, {"data": ["Non HTTP response code: java.net.SocketTimeoutException/Non HTTP response message: Read timed out", 2895, 46.535926699887476, 2.482059723758327], "isController": false}, {"data": ["Non HTTP response code: org.apache.http.conn.ConnectTimeoutException/Non HTTP response message: Connect to www.blazedemo.com:443 [www.blazedemo.com/172.217.192.121] failed: Read timed out", 189, 3.038096769008198, 0.162041204763497], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 116637, 6221, "Non HTTP response code: java.net.SocketTimeoutException/Non HTTP response message: Read timed out", 2895, "Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: www.blazedemo.com:443 failed to respond", 948, "Non HTTP response code: org.apache.http.conn.ConnectTimeoutException/Non HTTP response message: Connect to www.blazedemo.com:443 [www.blazedemo.com/172.217.192.121, www.blazedemo.com/2800:3f0:4003:c0f:0:0:0:79] failed: Read timed out", 557, "Non HTTP response code: org.apache.http.conn.ConnectTimeoutException/Non HTTP response message: Connect to www.blazedemo.com:443 [www.blazedemo.com/172.217.192.121] failed: Connect timed out", 377, "Non HTTP response code: org.apache.http.conn.ConnectTimeoutException/Non HTTP response message: Connect to www.blazedemo.com:443 [www.blazedemo.com/172.217.192.121, www.blazedemo.com/2800:3f0:4003:c0f:0:0:0:79] failed: Connect timed out", 328], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": ["HTTP_01_Home", 32763, 3472, "Non HTTP response code: java.net.SocketTimeoutException/Non HTTP response message: Read timed out", 887, "Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: www.blazedemo.com:443 failed to respond", 715, "Non HTTP response code: org.apache.http.conn.ConnectTimeoutException/Non HTTP response message: Connect to www.blazedemo.com:443 [www.blazedemo.com/172.217.192.121, www.blazedemo.com/2800:3f0:4003:c0f:0:0:0:79] failed: Read timed out", 451, "Non HTTP response code: org.apache.http.conn.ConnectTimeoutException/Non HTTP response message: Connect to www.blazedemo.com:443 [www.blazedemo.com/172.217.192.121] failed: Connect timed out", 322, "Non HTTP response code: org.apache.http.conn.ConnectTimeoutException/Non HTTP response message: Connect to www.blazedemo.com:443 [www.blazedemo.com/172.217.192.121, www.blazedemo.com/2800:3f0:4003:c0f:0:0:0:79] failed: Connect timed out", 260], "isController": false}, {"data": ["HTTP_04_Confirmar", 26927, 781, "Non HTTP response code: java.net.SocketTimeoutException/Non HTTP response message: Read timed out", 536, "Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: www.blazedemo.com:443 failed to respond", 77, "Non HTTP response code: org.apache.http.conn.ConnectTimeoutException/Non HTTP response message: Connect to www.blazedemo.com:443 [www.blazedemo.com/64.233.190.121, www.blazedemo.com/2800:3f0:4003:c08:0:0:0:79] failed: Read timed out", 40, "Non HTTP response code: org.apache.http.conn.ConnectTimeoutException/Non HTTP response message: Connect to www.blazedemo.com:443 [www.blazedemo.com/172.217.192.121, www.blazedemo.com/2800:3f0:4003:c0f:0:0:0:79] failed: Read timed out", 32, "Non HTTP response code: org.apache.http.conn.ConnectTimeoutException/Non HTTP response message: Connect to www.blazedemo.com:443 [www.blazedemo.com/172.217.192.121, www.blazedemo.com/2800:3f0:4003:c0f:0:0:0:79] failed: Connect timed out", 27], "isController": false}, {"data": ["HTTP_03_Selecionar", 27874, 861, "Non HTTP response code: java.net.SocketTimeoutException/Non HTTP response message: Read timed out", 602, "Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: www.blazedemo.com:443 failed to respond", 75, "Non HTTP response code: org.apache.http.conn.ConnectTimeoutException/Non HTTP response message: Connect to www.blazedemo.com:443 [www.blazedemo.com/172.217.192.121, www.blazedemo.com/2800:3f0:4003:c0f:0:0:0:79] failed: Read timed out", 39, "Non HTTP response code: org.apache.http.conn.ConnectTimeoutException/Non HTTP response message: Connect to www.blazedemo.com:443 [www.blazedemo.com/64.233.190.121, www.blazedemo.com/2800:3f0:4003:c08:0:0:0:79] failed: Read timed out", 33, "Non HTTP response code: org.apache.http.conn.ConnectTimeoutException/Non HTTP response message: Connect to www.blazedemo.com:443 [www.blazedemo.com/172.217.192.121, www.blazedemo.com/2800:3f0:4003:c0f:0:0:0:79] failed: Connect timed out", 21], "isController": false}, {"data": ["HTTP_02_Buscar", 29073, 1107, "Non HTTP response code: java.net.SocketTimeoutException/Non HTTP response message: Read timed out", 870, "Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: www.blazedemo.com:443 failed to respond", 81, "Non HTTP response code: org.apache.http.conn.ConnectTimeoutException/Non HTTP response message: Connect to www.blazedemo.com:443 [www.blazedemo.com/172.217.192.121, www.blazedemo.com/2800:3f0:4003:c0f:0:0:0:79] failed: Read timed out", 35, "Non HTTP response code: org.apache.http.conn.ConnectTimeoutException/Non HTTP response message: Connect to www.blazedemo.com:443 [www.blazedemo.com/64.233.190.121, www.blazedemo.com/2800:3f0:4003:c08:0:0:0:79] failed: Read timed out", 26, "Non HTTP response code: org.apache.http.conn.ConnectTimeoutException/Non HTTP response message: Connect to www.blazedemo.com:443 [www.blazedemo.com/172.217.192.121] failed: Connect timed out", 21], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
