/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 95.73090541224077, "KoPercent": 4.2690945877592315};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.3794891249367729, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.3277818448023426, 500, 1500, "HTTP_01_Home"], "isController": false}, {"data": [0.37194712077078196, 500, 1500, "HTTP_04_Confirmar"], "isController": false}, {"data": [0.41039124947412703, 500, 1500, "HTTP_03_Selecionar"], "isController": false}, {"data": [0.4127529966594616, 500, 1500, "HTTP_02_Buscar"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 19770, 844, 4.2690945877592315, 3219.5729893778575, 311, 51483, 1054.5, 8988.900000000001, 15245.950000000008, 30002.0, 81.16963097994778, 475.96504088761066, 20.06736422459805], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["HTTP_01_Home", 5464, 256, 4.685212298682284, 3883.6500732064505, 319, 51483, 1285.0, 11405.0, 17541.25, 30002.0, 22.843382359089276, 104.01172874450238, 2.594063291721364], "isController": false}, {"data": ["HTTP_04_Confirmar", 4463, 324, 7.259690790947793, 3697.8220927627062, 312, 46998, 1087.0, 11039.999999999998, 20005.8, 30002.0, 19.910596381027162, 108.15277638750715, 7.573596125620115], "isController": false}, {"data": ["HTTP_03_Selecionar", 4754, 130, 2.7345393352965925, 2626.2214976861674, 315, 45761, 946.5, 6542.5, 10845.5, 30003.0, 20.02392425110355, 129.35526983096128, 5.6869455933888196], "isController": false}, {"data": ["HTTP_02_Buscar", 5089, 134, 2.6331302809982313, 2641.4338769895803, 311, 45604, 949.0, 6477.0, 10666.0, 30002.0, 21.49316011538478, 152.44684106058335, 5.150057359791869], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["Non HTTP response code: java.net.SocketException/Non HTTP response message: Connection reset", 15, 1.7772511848341233, 0.07587253414264036], "isController": false}, {"data": ["Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: www.blazedemo.com:443 failed to respond", 137, 16.232227488151658, 0.6929691451694486], "isController": false}, {"data": ["Non HTTP response code: org.apache.http.conn.ConnectTimeoutException/Non HTTP response message: Connect to www.blazedemo.com:443 [www.blazedemo.com/172.217.192.121, www.blazedemo.com/2800:3f0:4003:c0f:0:0:0:79] failed: Read timed out", 61, 7.2274881516587675, 0.3085483055134042], "isController": false}, {"data": ["Non HTTP response code: java.net.SocketTimeoutException/Non HTTP response message: Read timed out", 487, 57.70142180094787, 2.4633282751643906], "isController": false}, {"data": ["Non HTTP response code: org.apache.http.conn.ConnectTimeoutException/Non HTTP response message: Connect to www.blazedemo.com:443 [www.blazedemo.com/172.217.192.121, www.blazedemo.com/2800:3f0:4003:c0f:0:0:0:79] failed: Connect timed out", 144, 17.061611374407583, 0.7283763277693475], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 19770, 844, "Non HTTP response code: java.net.SocketTimeoutException/Non HTTP response message: Read timed out", 487, "Non HTTP response code: org.apache.http.conn.ConnectTimeoutException/Non HTTP response message: Connect to www.blazedemo.com:443 [www.blazedemo.com/172.217.192.121, www.blazedemo.com/2800:3f0:4003:c0f:0:0:0:79] failed: Connect timed out", 144, "Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: www.blazedemo.com:443 failed to respond", 137, "Non HTTP response code: org.apache.http.conn.ConnectTimeoutException/Non HTTP response message: Connect to www.blazedemo.com:443 [www.blazedemo.com/172.217.192.121, www.blazedemo.com/2800:3f0:4003:c0f:0:0:0:79] failed: Read timed out", 61, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Connection reset", 15], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": ["HTTP_01_Home", 5464, 256, "Non HTTP response code: java.net.SocketTimeoutException/Non HTTP response message: Read timed out", 140, "Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: www.blazedemo.com:443 failed to respond", 70, "Non HTTP response code: org.apache.http.conn.ConnectTimeoutException/Non HTTP response message: Connect to www.blazedemo.com:443 [www.blazedemo.com/172.217.192.121, www.blazedemo.com/2800:3f0:4003:c0f:0:0:0:79] failed: Connect timed out", 21, "Non HTTP response code: org.apache.http.conn.ConnectTimeoutException/Non HTTP response message: Connect to www.blazedemo.com:443 [www.blazedemo.com/172.217.192.121, www.blazedemo.com/2800:3f0:4003:c0f:0:0:0:79] failed: Read timed out", 14, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Connection reset", 11], "isController": false}, {"data": ["HTTP_04_Confirmar", 4463, 324, "Non HTTP response code: org.apache.http.conn.ConnectTimeoutException/Non HTTP response message: Connect to www.blazedemo.com:443 [www.blazedemo.com/172.217.192.121, www.blazedemo.com/2800:3f0:4003:c0f:0:0:0:79] failed: Connect timed out", 119, "Non HTTP response code: java.net.SocketTimeoutException/Non HTTP response message: Read timed out", 100, "Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: www.blazedemo.com:443 failed to respond", 57, "Non HTTP response code: org.apache.http.conn.ConnectTimeoutException/Non HTTP response message: Connect to www.blazedemo.com:443 [www.blazedemo.com/172.217.192.121, www.blazedemo.com/2800:3f0:4003:c0f:0:0:0:79] failed: Read timed out", 46, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Connection reset", 2], "isController": false}, {"data": ["HTTP_03_Selecionar", 4754, 130, "Non HTTP response code: java.net.SocketTimeoutException/Non HTTP response message: Read timed out", 123, "Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: www.blazedemo.com:443 failed to respond", 5, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Connection reset", 1, "Non HTTP response code: org.apache.http.conn.ConnectTimeoutException/Non HTTP response message: Connect to www.blazedemo.com:443 [www.blazedemo.com/172.217.192.121, www.blazedemo.com/2800:3f0:4003:c0f:0:0:0:79] failed: Read timed out", 1, "", ""], "isController": false}, {"data": ["HTTP_02_Buscar", 5089, 134, "Non HTTP response code: java.net.SocketTimeoutException/Non HTTP response message: Read timed out", 124, "Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: www.blazedemo.com:443 failed to respond", 5, "Non HTTP response code: org.apache.http.conn.ConnectTimeoutException/Non HTTP response message: Connect to www.blazedemo.com:443 [www.blazedemo.com/172.217.192.121, www.blazedemo.com/2800:3f0:4003:c0f:0:0:0:79] failed: Connect timed out", 4, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Connection reset", 1, "", ""], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
